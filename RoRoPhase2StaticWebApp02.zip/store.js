// store.js
import { reactive } from 'https://unpkg.com/vue@3/dist/vue.esm-browser.js';

const store = reactive({
  messages: [
    { who: 'ai', text: 'こんにちは！わんちゃんの様子はいかがですか？', avatar: 'https://i.pravatar.cc/40?img=12' }
  ],
  quickReplies: ['ご飯のおすすめ', '散歩の時間', '健康診断について']
});

export default store;
