// views/HomeView.js
import { reactive, ref } from 'https://unpkg.com/vue@3/dist/vue.esm-browser.js';

export default {
  name: 'HomeView',
  setup() {
    const stats = reactive([
      { label: '登録ユーザー数',   value: 75 },
      { label: 'レポート生成数',   value: 60 },
      { label: 'アルバム作成数',   value: 45 },
      { label: 'リテンション率',   value: 85 }
    ]);
    const newsletterEmail = ref('');
    const subscribed      = ref(false);
    function subscribe() {
      if (!newsletterEmail.value) return;
      subscribed.value = true;
    }
    return { stats, newsletterEmail, subscribed, subscribe };
  },
  template: `
    <div>
      <section class="position-relative overflow-hidden" style="height: 80vh;">
        <video autoplay muted loop playsinline
               class="position-absolute w-100 h-100 object-fit-cover">
          <source src="https://www.pexels.com/download/video/7982689/" type="video/mp4" />
        </video>
        <div class="position-relative text-center text-white d-flex flex-column justify-content-center align-items-center h-100 bg-dark bg-opacity-50">
          <h1 class="display-3 fw-bold">ようこそ、Project ROROへ</h1>
          <p class="lead mb-4">あなたのペットライフをAIでより豊かに</p>
          <router-link to="/chat" class="btn btn-lg btn-light">今すぐはじめる</router-link>
        </div>
      </section>
      <section class="bg-primary text-white py-5">
        <div class="container text-center">
          <h2 class="mb-3">最新情報をお届け</h2>
          <div class="row justify-content-center">
            <div class="col-md-6">
              <div class="input-group">
                <input type="email" class="form-control" placeholder="メールアドレス" v-model="newsletterEmail" />
                <button class="btn btn-light" @click="subscribe" :disabled="subscribed">
                  {{ subscribed ? '登録済み' : '登録する' }}
                </button>
              </div>
              <p v-if="subscribed" class="mt-2">ご登録ありがとうございます！</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  `
};
