// components/PrivacyFooter.js
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'PrivacyFooter',
  template: `
    <footer class="text-center py-3 bg-light">
      <small class="text-muted">
        本サービスは個人情報保護法・GDPR・CCPA を遵守します。
        <router-link to="/privacy">プライバシーポリシー</router-link>
      </small>
    </footer>
  `
});
