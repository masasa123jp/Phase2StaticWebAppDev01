// main.js
import { createApp } from 'vue';
import { createRouter, createWebHashHistory } from 'vue-router';

import App           from './components/App.js';
import HomeView      from './views/HomeView.js';
import ChatView      from './views/ChatView.js';
import AlbumView     from './views/AlbumView.js';
import SettingsView  from './views/SettingsView.js';
import ReportView    from './views/ReportView.js';
import PrivacyView   from './views/PrivacyView.js';

const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/',         name: 'home',    component: HomeView     },
    { path: '/chat',     name: 'chat',    component: ChatView     },
    { path: '/album',    name: 'album',   component: AlbumView    },
    { path: '/settings', name: 'settings',component: SettingsView },
    { path: '/report',   name: 'report',  component: ReportView   },
    { path: '/privacy',  name: 'privacy', component: PrivacyView  }
  ]
});

createApp(App).use(router).mount('#app');
