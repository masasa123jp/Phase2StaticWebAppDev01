// views/AlbumView.js
import {
  ref,
  reactive,
  computed,
  onMounted
} from 'https://unpkg.com/vue@3/dist/vue.esm-browser.js';

export default {
  name: 'AlbumView',
  setup() {
    // サンプルデータ
    const photos = reactive([
      { id:1, date:'2025-05-01', tags:['散歩'], src:'https://picsum.photos/300/200?random=1' },
      { id:2, date:'2025-05-03', tags:['ご飯'], src:'https://picsum.photos/300/200?random=2' },
      { id:3, date:'2025-05-05', tags:['遊ぶ'], src:'https://picsum.photos/300/200?random=3' },
      { id:4, date:'2025-05-07', tags:['お昼寝'], src:'https://picsum.photos/300/200?random=4' },
      { id:5, date:'2025-05-09', tags:['シャンプー'], src:'https://picsum.photos/300/200?random=5' },
      { id:6, date:'2025-05-11', tags:['散歩'], src:'https://picsum.photos/300/200?random=6' },
      { id:7, date:'2025-05-13', tags:['おやつ'], src:'https://picsum.photos/300/200?random=7' }
    ]);

    const filterDate  = ref('');
    const filterTag   = ref('');
    const currentPage = ref(1);
    const perPage     = 6;

    const filtered = computed(() =>
      photos.filter(p =>
        (!filterDate.value || p.date === filterDate.value) &&
        (!filterTag.value || p.tags.includes(filterTag.value))
      )
    );

    const totalPages = computed(() =>
      Math.ceil(filtered.value.length / perPage)
    );

    const paged = computed(() => {
      const start = (currentPage.value - 1) * perPage;
      return filtered.value.slice(start, start + perPage);
    });

    function openModal(src) {
      const img = document.getElementById('albumModalImg');
      if (img) {
        img.src = src;
        new bootstrap.Modal(document.getElementById('albumModal')).show();
      }
    }

    function changePage(n) {
      if (n < 1 || n > totalPages.value) return;
      currentPage.value = n;
    }

    return {
      filterDate,
      filterTag,
      paged,
      totalPages,
      currentPage,
      openModal,
      changePage
    };
  },
  template: `
    <div class="container py-4">
      <h3>フォトアルバム</h3>
      <div class="row g-3 mb-3">
        <div class="col-md-6">
          <label class="form-label">日付で絞り込み</label>
          <input type="date" class="form-control" v-model="filterDate" />
        </div>
        <div class="col-md-6">
          <label class="form-label">タグで絞り込み</label>
          <select class="form-select" v-model="filterTag">
            <option value="">すべて</option>
            <option>散歩</option>
            <option>ご飯</option>
            <option>遊ぶ</option>
            <option>お昼寝</option>
            <option>シャンプー</option>
            <option>おやつ</option>
          </select>
        </div>
      </div>

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col" v-for="photo in paged" :key="photo.id">
          <div class="card h-100">
            <img :src="photo.src" class="card-img-top" @click="openModal(photo.src)" style="cursor:pointer;" />
            <div class="card-body">
              <p class="card-text">
                {{ photo.date }}<br/>
                タグ: <span class="badge bg-secondary" v-for="tag in photo.tags" :key="tag">{{ tag }}</span>
              </p>
            </div>
          </div>
        </div>
      </div>

      <nav aria-label="Page navigation" class="mt-4">
        <ul class="pagination justify-content-center">
          <li class="page-item" :class="{ disabled: currentPage===1 }">
            <a class="page-link" href="#" @click.prevent="changePage(currentPage-1)">前へ</a>
          </li>
          <li class="page-item" v-for="n in totalPages" :class="{ active: n===currentPage }" :key="n">
            <a class="page-link" href="#" @click.prevent="changePage(n)">{{ n }}</a>
          </li>
          <li class="page-item" :class="{ disabled: currentPage===totalPages }">
            <a class="page-link" href="#" @click.prevent="changePage(currentPage+1)">次へ</a>
          </li>
        </ul>
      </nav>

      <!-- モーダル -->
      <div class="modal fade" id="albumModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <img id="albumModalImg" src="" class="img-fluid" />
          </div>
        </div>
      </div>
    </div>
  `
};
