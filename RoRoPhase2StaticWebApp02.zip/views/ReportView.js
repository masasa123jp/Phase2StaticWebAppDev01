// views/ReportView.js
import {
  defineComponent,
  ref,
  onMounted
} from 'https://unpkg.com/vue@3/dist/vue.esm-browser.js';
import DataService    from '../services/DataService.js';
import ReportCharts   from '../components/ReportCharts.js';
import ExportService  from '../services/ExportService.js';

export default defineComponent({
  name: 'ReportView',
  components: { ReportCharts },
  setup() {
    const loading     = ref(true);
    const healthStats = ref({});
    const regionInfo  = ref({});
    const concernRecs = ref([]);
    const reportCard  = ref(null);

    onMounted(async () => {
      const result = await DataService.fetchReportData();
      healthStats.value = result.healthStats;
      regionInfo.value  = result.regionInfo;
      concernRecs.value = result.concernRecs;
      loading.value     = false;
    });

    function downloadPDF() {
      if (reportCard.value) {
        ExportService.exportPDF(reportCard.value, 'RORO_Report.pdf');
      }
    }

    function downloadCSV() {
      const data = Object.entries(healthStats.value).flatMap(([breed,stats]) =>
        Object.entries(stats).map(([age,count]) => ({ 種別: breed, 年齢: age, 件数: count }))
      );
      ExportService.exportCSV(data, 'HealthStats.csv');
    }

    return {
      loading,
      healthStats,
      regionInfo,
      concernRecs,
      reportCard,
      downloadPDF,
      downloadCSV
    };
  },
  template: `
    <div class="container py-4">
      <h3>詳細レポート</h3>
      <div v-if="loading" class="text-center py-5">
        <div class="spinner-border text-primary" role="status"></div>
      </div>
      <div v-else ref="reportCard" class="card p-4">
        <ReportCharts
          :healthStats="healthStats"
          :regionInfo="regionInfo"
          :concernRecs="concernRecs"
        />
        <div class="mt-4">
          <h5>まとめ</h5>
          <p>
            ・アドバイス件数合計：
            <strong>{{ Object.values(healthStats).flatMap(o=>Object.values(o)).reduce((a,b)=>a+b,0) }} 件</strong><br/>
            ・施設数合計：
            <strong>{{ Object.values(regionInfo).flat().length }} 箇所</strong><br/>
            ・教材提案数：
            <strong>{{ Object.values(concernRecs).flat().length }} 種類</strong>
          </p>
        </div>
        <div class="text-end mt-3">
          <button class="btn btn-outline-secondary me-2" @click="downloadCSV">
            <i class="bi bi-file-earmark-spreadsheet"></i> CSVダウンロード
          </button>
          <button class="btn btn-primary" @click="downloadPDF">
            <i class="bi bi-file-earmark-pdf"></i> PDFダウンロード
          </button>
        </div>
      </div>
    </div>
  `
});
