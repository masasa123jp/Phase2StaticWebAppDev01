// views/SettingsView.js
import {
  ref,
  reactive
} from 'https://unpkg.com/vue@3/dist/vue.esm-browser.js';

export default {
  name: 'SettingsView',
  setup() {
    const activeTab = ref('profile');
    const profile = reactive({
      owner: '',
      pet: '',
      avatar: ''
    });
    const notifications = reactive({
      newsletter: true,
      updates:    false
    });
    const theme = ref('light');

    function uploadAvatar(e) {
      const file = e.target.files[0];
      profile.avatar = file ? URL.createObjectURL(file) : '';
    }

    return {
      activeTab,
      profile,
      notifications,
      theme,
      uploadAvatar
    };
  },
  template: `
    <div class="container py-4">
      <h3>設定</h3>
      <ul class="nav nav-tabs mb-3">
        <li class="nav-item">
          <button class="nav-link" :class="{active: activeTab==='profile'}"
                  @click="activeTab='profile'">プロフィール</button>
        </li>
        <li class="nav-item">
          <button class="nav-link" :class="{active: activeTab==='notifications'}"
                  @click="activeTab='notifications'">通知設定</button>
        </li>
        <li class="nav-item">
          <button class="nav-link" :class="{active: activeTab==='theme'}"
                  @click="activeTab='theme'">テーマ</button>
        </li>
      </ul>

      <div v-if="activeTab==='profile'">
        <form class="row g-3">
          <div class="col-md-6">
            <label class="form-label">オーナー名</label>
            <input v-model="profile.owner" type="text" class="form-control" placeholder="例: 田中 花子"/>
          </div>
          <div class="col-md-6">
            <label class="form-label">ペット名</label>
            <input v-model="profile.pet" type="text" class="form-control" placeholder="例: ココ"/>
          </div>
          <div class="col-12">
            <label class="form-label">アバター</label>
            <input type="file" @change="uploadAvatar" class="form-control"/>
            <img v-if="profile.avatar" :src="profile.avatar" class="mt-2 rounded" width="120"/>
          </div>
        </form>
      </div>

      <div v-else-if="activeTab==='notifications'">
        <form>
          <div class="form-check">
            <input v-model="notifications.newsletter" class="form-check-input" type="checkbox" id="nl"/>
            <label class="form-check-label" for="nl">ニュースレターを受け取る</label>
          </div>
          <div class="form-check">
            <input v-model="notifications.updates" class="form-check-input" type="checkbox" id="upd"/>
            <label class="form-check-label" for="upd">アップデート情報</label>
          </div>
        </form>
      </div>

      <div v-else>
        <label class="form-label">テーマ</label>
        <select v-model="theme" class="form-select" style="max-width:200px;">
          <option value="light">ライト</option>
          <option value="dark">ダーク</option>
        </select>
      </div>
    </div>
  `
};
